﻿using System.Linq;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
//poorly written by pr0skynesis (discord username)

namespace CookedInfo
{
    [BepInPlugin(pluginGuid, pluginName, pluginVersion)]
    public class CookedInfoMain : BaseUnityPlugin
    {
        // Necessary plugin info
        public const string pluginGuid = "pr0skynesis.cookedinfo";
        public const string pluginName = "Cooked Info";
        public const string pluginVersion = "1.1.0";

        //config file info
        public static ConfigEntry<bool> configColoredText;
        public static ConfigEntry<bool> configCookingPercent;
        public static ConfigEntry<bool> configCookingBar;
        public static ConfigEntry <bool> configNameAllFood;
        public void Awake()
        {
            //Logger.LogInfo("Cooked Info is loaded!");
            //Create config file in BepInEx\config\
            configColoredText = Config.Bind("Colored Text", "showColoredText", true, "Enables the colored text for raw, cooked and burnt food, change to false to disable it.");
            configCookingPercent = Config.Bind("Cooking Percentage", "showCookingPercent", true, "Enables the cooking percentage when cooking food, change to false to disable it.");
            configCookingBar = Config.Bind("Loading Bar", "showCookingBar", true, "Enables the cooking loading bar when cooking food, change to false to disable it.");
            configNameAllFood = Config.Bind("Name All Food", "nameAllFood", true, "Display names for all foods items, like bread, and applies the cookedinfo to them as well.");

            //patching info
            Harmony harmony = new Harmony(pluginGuid);
            MethodInfo original = AccessTools.Method(typeof(CookableFood), "UpdateMaterial");
            MethodInfo patch = AccessTools.Method(typeof(CookedInfoPatches), "UpdateMaterial_Patch");

            harmony.Patch(original, new HarmonyMethod(patch)); //patch applied
        }
    }
    public class CookedInfoPatches   //contains the patch
    {
        //hex color values
        static readonly string red = "#4D0000";
        static readonly string green = "#003300";
        static readonly string yellow = "#CC7F00";
        //list of the foods that don't display a name by default
        static readonly string[] noNameFoods = { "sausage", "dates", "bread", "banana", "bun", "crab cake", "cheese", "goat cheese", "lamb", "rice cake", "forest mushroom", "field mushroom", "cave mushroom", "orange" };
        
        [HarmonyPostfix] //patch happens after the original
        public static void UpdateMaterial_Patch(ShipItem ___item)
        {   //There are five possible situations depending on the value of __item.amount
            if (noNameFoods.Contains(___item.name) && ___item.amount == 0f && CookedInfoMain.configNameAllFood.Value)
            {   //if the item is a noNameFoods, then use the name as description (e.g. bread, orange, dates)
                //the check for amount == 0f is so that we don't get stuff like "Raw Orange"!
                ___item.description = ___item.name;
            }
            if (CookedInfoMain.configColoredText.Value && ___item.description != "") //second check is needed for cases where nameAllFood is false
            {   //things happens with colored text.
                
                if (___item.amount == 0f && !noNameFoods.Contains(___item.name))
                {   //yellow, but only to OG named foods (eg fishes), so we don't get stuff like "Raw orange"!
                    ___item.description = $"\n<color={yellow}>{BuildDescription(___item)}</color>";
                }
                if (___item.amount > 0f && ___item.amount < 1f)
                {   //yellow
                    ___item.description = $"\n<color={yellow}>{BuildDescription(___item)}</color>";
                }
                if (___item.amount >=1f && ___item.amount <1.5f)
                {   //green
                    ___item.description = $"\n<color={green}>{BuildDescription(___item)}</color>";
                }
                if (___item.amount >1.5f)
                {   //red.
                    ___item.description = $"\n<color={red}>{BuildDescription(___item)}</color>";
                }
            }
            else if (CookedInfoMain.configColoredText.Value == false && ___item.description != "")
            {   //things happens without colored text.
                ___item.description = $"\n{BuildDescription(___item)}";
            }
        }
        private static string BuildDescription(ShipItem food)
        {   //this gets the description all toghether.
            return $"{CookedStatus(food)}{CookedPercent(food.amount)}{CookingBar(food.amount)}";
        }
        private static string CookedStatus(ShipItem food)
        {   //returns the food status (0 = raw, 1 = undercooked, 2 = cooked, 3 = overcooked, 4 = burnt)
            if (food.amount <= 0f)
            {   //raw
                return $"Raw {food.name}";
            }
            else if (food.amount > 0f && food.amount < 1f)
            {   //undercooked
                return $"Undercooked {food.name}";
            }
            else if (food.amount >= 1f && food.amount < 1.5f)
            {   //cooked
                return $"Cooked {food.name}";
            }
            else if (food.amount >= 1.5f && food.amount < 1.75f)
            {   //overcooked
                return $"Overcooked {food.name}";
            }
            else
            {   //burnt (over 1.75f)
                return $"Burnt {food.name}";
            }
        }
        private static string CookedPercent( float amount)
        {   //returns the % string
            if (!CookedInfoMain.configCookingPercent.Value)
            {   //empty string if we don't want the %
                return "";
            }
            int percent = Mathf.RoundToInt(amount * 100);

            return $"\n<b>{percent}%</b>";
        }
        private static string CookingBar( float amount)
        {   //possibly useful ASCII characters: ████░░░░░░ ████▒▒▒▒ ■□□□□ ▄▄▄... ▀▀    ═══───
            //returns a the loading bar
            if(!CookedInfoMain.configCookingBar.Value)
            {   //empty string if we don't want the bar
                return "";
            }
            int barLength = 300; // Total length of the loading bar
            int filledLength = (int)(amount * barLength); // Calculate the number of filled characters
            
            if (filledLength <= 0 || filledLength >= barLength)
                {   //empty string if raw or fully cooked already.
                    return "";
                }
            else
            {
                StringBuilder bar = new StringBuilder();
                for (int i = 0; i < barLength; i++)
                {
                    if (i < filledLength)
                    {
                        bar.Append("█"); // Filled character
                    }
                    else
                    {
                        bar.Append("░"); // Empty character
                    }
                }
                return $"\n<size=3%>{bar}</size>";
            }
        }
    }
}
